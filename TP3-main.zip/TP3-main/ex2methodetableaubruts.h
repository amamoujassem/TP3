#ifndef EX2METHODETABLEAUBRUTS_H
#define EX2METHODETABLEAUBRUTS_H
void remplir(int t[], int n);
#endif